DPL 2026 — Team Logos
=====================

logos-1024/  square transparent PNG, 1024x1024 (primary use)
logos-512/   square transparent PNG, 512x512 (web/app avatars)

Team mapping:
DSK  Digi Super Kings       logos-1024/DSK-Digi-Super-Kings.png   logos-512/DSK-Digi-Super-Kings.png
SM   Sahyadriche Mavale     logos-1024/SM-Sahyadriche-Mavale.png   logos-512/SM-Sahyadriche-Mavale.png
DMM  Digi Mitra Mandal      logos-1024/DMM-Digi-Mitra-Mandal.png   logos-512/DMM-Digi-Mitra-Mandal.png
BB   Bhakarwadi Blasters    logos-1024/BB-Bhakarwadi-Blasters.png   logos-512/BB-Bhakarwadi-Blasters.png
DD   Digi Dhadakebaaz       logos-1024/DD-Digi-Dhadakebaaz.png   logos-512/DD-Digi-Dhadakebaaz.png
CW   Cricket Wala           logos-1024/CW-Cricket-Wala.png   logos-512/CW-Cricket-Wala.png
DT   Digi Titans            logos-1024/DT-Digi-Titans.png   logos-512/DT-Digi-Titans.png
DY   Digi Yodhas            logos-1024/DY-Digi-Yodhas.png   logos-512/DY-Digi-Yodhas.png
GM   Gallit Maramari        logos-1024/GM-Gallit-Maramari.png   logos-512/GM-Gallit-Maramari.png
DDH  Digi Dhurandhars       logos-1024/DDH-Digi-Dhurandhars.png   logos-512/DDH-Digi-Dhurandhars.png

Logos are transparent PNGs centred on a square canvas, so they can be
dropped onto any colour without clipping.
